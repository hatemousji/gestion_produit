package com.asking.api_produit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProduitApplicationTests {

	@Test
	void contextLoads() {
	}

}
